<?php $__env->startSection('content'); ?>
<body class="d-flex flex-column">
<div id="page-content">
    <div class="container">
            <div class="row mt-3">
                <form class="col-md-6 mt-1">
                    <div class="form-group">
                        <select class="form-control font-weight-bold select_dia" onChange="window.location.href=this.value">
                            <option>Relatório diário:</option>
                            <?php if(empty($consulta["listRastreio"])): ?>
                                <?php $__currentLoopData = $consulta["listRastreio"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value='exportar.php?data_cadastro=<?php echo e($row['data_cadastro']); ?>'><?php echo e($row['data_cadastro']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                </form>
                <form class="col-md-6 my-1">
                    <div class="form-group">
                        <select class="form-control font-weight-bold select_mes" onChange="window.location.href=this.value">
                            <option>Relatório mensal: </option>

                            <?php if(!empty($consulta["distData"])): ?> {
                            <?php $__currentLoopData = $consulta["distData"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option class='optSel' value='<?php echo e(route('exportarMes')); ?>?mes_inicio=<?php echo e($row['data_cadastro']); ?>-01&mes_final=<?php echo e($row['data_cadastro']); ?>-31'>
                                    <?php echo e(\App\Helpers\Utils::mes_atual($row['data_cadastro'])); ?>

                                </option>";
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr><td colspan='5'><center>No Data Avaliable</center></td></tr>
                            <?php endif; ?>

                        </select>
                    </div>
                </form>
        </div>

        <h5 class="mt-3 mb-3">Lista de rastreios <span class="mes_sel"><?php echo \App\Helpers\Utils::mes_atual(substr($consulta["mes_inicio"], 0, 7))?></span> - Total: <?php echo $consulta["qntd_rastreios_mes"] ?></h5>
        <div class="box-table table-responsive load">
            <table class="codigosTable export table table-sm table-striped" data-order='[[ 0, "desc" ]]' data-page-length='10'>
                <thead>
                <tr class="table-dark">
                    <th class="d-none"><strong>ID</strong></th>
                    <th><strong>Rastreio</strong></th>
                    <th><strong>Data</strong></th>
                    <th><strong>Hora</strong></th>
                </tr>
                </thead>
                <tbody>
                <?php
                if(!empty($consulta["consulta"])) {
                    foreach($consulta["consulta"] as $row) {
                        echo "<tr><td class='d-none'>".$row['id']."</td>
											<td><span class='cod-rastreio font-weight-bolder text-uppercase'>".$row['cod_rastreio']."</span></td>
											<td><span>".\App\Helpers\Utils::formata_data($row['data_cadastro'])."</span></td>
											<td><span>".$row['hora_cadastro']."</span></td>
						</tr>";
                    }
                } else {
                    echo "<script> var element = document.getElementsByClassName('box-table')[0]; element.classList.remove('load'); </script>";
                    echo "<tr><td colspan='3'><center class='py-4 font-weight-bolder'>Não existem rastreios cadastrados nesta data.</center></td></tr>";
                }
                ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="footer">
    <div class="container">
        <div class="col-12 py-4 text-center">
            <img src="<?php echo e(url('images/logo-footer.svg')); ?>" class="d-block mx-auto">
            <span class="text-muted">Powered by: <a href="http://efetive.com" target="blank">Efetive</a>  &copy; 2020</span>
        </div>
    </div>
</div>
<script src="<?php echo e(url('js/jquery-3.3.1.min.js')); ?>"></script>
<script src="<?php echo e(url('js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(url('js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(url('js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(url('js/buttons.flash.min.js')); ?>"></script>
<script src="<?php echo e(url('js/jszip.min.js')); ?>"></script>
<script src="<?php echo e(url('js/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(url('js/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(url('js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(url('js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(url('js/_main.js')); ?>"></script>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\bipei\resources\views/exportarMes.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
        <meta http-equiv="Content-Language" content="pt-BR" />
        <!-- Styles -->
        <link href="<?php echo e(url('css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(url('css/jquery.dataTables.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(url('css/main.css')); ?>" rel="stylesheet">
        <link rel="icon" href="favicon.ico" type="image/x-icon">
    </head>
    <body class="login d-flex align-items-center">


                <div class="container">
                    <img src="<?php echo e(url('images/logo-login.svg')); ?>" class="d-block mx-auto">
                    <div class="col-sm-8 offset-sm-2 col-md-4 offset-md-4 mt-2 mb-5 py-3 bg-white rounded shadow">
                        <div class="wrapper">
                            <form action="<?php echo e(route('login')); ?>" method="post" name="Login_Form" class="form-signin">
                                <?php echo csrf_field(); ?>

                                <input id="email" type="email" class="form-control my-2 font-weight-bold <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input id="password" type="password" class="form-control my-2 font-weight-bold <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <button class="btn btn-lg btn-primary btn-block my-2 font-weight-bolder"  name="Submit" value="Login" type="Submit">Entrar</button>
                                <div class="container" style="text-align: center">
                                <?php if(Route::has('login')): ?>
                                    <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
                                        <?php if(auth()->guard()->check()): ?>
                                        <?php else: ?>
                                            <?php if(Route::has('register')): ?>
                                                <a href="<?php echo e(route('register')); ?>" class="text-sm text-gray-700 underline">Register</a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
    </body>
</html>
<?php /**PATH C:\projetos\bipei\resources\views/welcome.blade.php ENDPATH**/ ?>
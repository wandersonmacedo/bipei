<?php $__env->startSection('content'); ?>
<body class="d-flex flex-column">
<div id="page-content">
    <div class="container">
        <div class="row mt-3">
            <form class="col-md-6 mt-1">
                <div class="form-group">
                    <select class="form-control font-weight-bold select_dia" onChange="window.location.href=this.value">
                        <option>Relatório diário:</option>
                        <?php if(!empty($info["listRastreio"])): ?>
                            <?php $__currentLoopData = $info["listRastreio"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value='<?php echo e(route('exportar')); ?>?data_cadastro=<?php echo e($row->data_cadastro); ?>'><?php echo e(\App\Helpers\Utils::formata_data($row->data_cadastro)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
            </form>
            <form class="col-md-6 my-1">
                <div class="form-group">
                    <select class="form-control font-weight-bold select_mes" onChange="window.location.href=this.value">
                        <option>Relatório mensal: </option>

                        <?php if(!empty($info["distData"])): ?> {
                            <?php $__currentLoopData = $info["distData"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option class='optSel' value='<?php echo e(route('exportarMes')); ?>?mes_inicio=<?php echo e($row->data_cadastro); ?>-01&mes_final=<?php echo e($row->data_cadastro); ?>-31'>
                                    <?php echo e(\App\Helpers\Utils::mes_atual($row->data_cadastro)); ?>

                                </option>";
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr><td colspan='5'><center>No Data Avaliable</center></td></tr>
                        <?php endif; ?>

                    </select>
                </div>
            </form>
        </div>
        <h5 class="mt-3 mb-3">Lista de rastreios <span class="dia_sel"><?php echo e(\App\Helpers\Utils::formata_data($info["DataCadastro"])); ?></span>
            <?php if($info["qntd_rastreios_dia"]==1) {?>
            - Total de <?php echo $info["qntd_rastreios_dia"];?> rastreio
            <?php }else if($info["qntd_rastreios_dia"]>1) { ?>
            - Total de <?php echo $info["qntd_rastreios_dia"];?> rastreios
            <?php } ?>
        </h5>
        <div class="box-table table-responsive load">
            <table class="codigosTable export table table-sm table-striped" data-order='[[ 0, "desc" ]]' data-page-length='10'>
                <thead>
                <tr class="table-dark">
                    <th class="d-none">Id</th>
                    <th>Rastreio</th>
                    <th>Cadastro</th>
                    <th>Data</th>
                </tr>
                </thead>
                <tbody>
                <?php if(!empty($info["selectBeetween"])): ?>
                    <?php $__currentLoopData = $info["selectBeetween"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class='d-none'><?php echo e($rows['id']); ?></td>
                            <td><span class='cod-rastreio font-weight-bolder text-uppercase'><?php echo e($rows['cod_rastreio']); ?></span></td>
                            <td><?php echo e(\App\Helpers\Utils::formata_data($rows['data_cadastro'])); ?></td>
                            <td><?php echo e($rows['hora_cadastro']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <script>
                        var element = document.getElementsByClassName('box-table')[0];
                        element.classList.remove('load');
                    </script>
                    <tr><td colspan='5'><center class='py-4 font-weight-bolder'>Não existem rastreios cadastrados nesta data.</center></td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
<div class="footer">
    <div class="container">
        <div class="col-12 py-4 text-center">
            <img src="images/logo-footer.svg" class="d-block mx-auto">
            <span class="text-muted">Powered by: <a href="http://efetive.com" target="blank">Efetive</a>  &copy; 2020</span>
        </div>
    </div>
</div>
<script src="<?php echo e(url('js/jquery-3.3.1.min.js')); ?>"></script>
<script src="<?php echo e(url('js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(url('js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(url('js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(url('js/buttons.flash.min.js')); ?>"></script>
<script src="<?php echo e(url('js/jszip.min.js')); ?>"></script>
<script src="<?php echo e(url('js/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(url('js/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(url('js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(url('js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(url('js/_main.js')); ?>"></script>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\f_dis\Documents\GitHub\bipei\resources\views/exportar.blade.php ENDPATH**/ ?>